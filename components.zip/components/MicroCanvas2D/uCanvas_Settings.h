#define MAX_ELEMENTS_NUM                        (512)
#define UCANVAS_TASK_STACK_SIZE                 (2046)
#define UCANVAS_RENDER_TASK_STACK_SIZE          (4096)
#define UCANVAS_RENDER_TASK_PRIORITY            (2)

#define UCANVAS_DEFAULT_RED                     (255)
#define UCANVAS_DEFAULT_GREEN                   (255)
#define UCANVAS_DEFAULT_BLUE                    (255)