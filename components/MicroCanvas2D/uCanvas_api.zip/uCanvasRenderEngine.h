#include <stdio.h>
#include <string.h>

#include "uCanvas_api.h"

/**
 * APIs for setting up uCanvas
*/
void uCanvas_bg_render_engine_task(void*arg);

